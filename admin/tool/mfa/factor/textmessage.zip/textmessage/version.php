<?php
defined('MOODLE_INTERNAL') || die();


$plugin->component = 'factor_textmessage';
$plugin->version   = 2025070801;
$plugin->requires  = 2022041900;
$plugin->maturity  = MATURITY_STABLE;
$plugin->release   = 'v1.0';

