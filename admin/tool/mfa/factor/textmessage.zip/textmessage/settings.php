<?php
defined('MOODLE_INTERNAL') || die();

if ($hassiteconfig) { // Only for site admins.

    // Create a new settings page for this factor.
    $settings = new admin_settingpage(
        'factor_textmessage',                 // Unique identifier
        get_string('pluginname', 'factor_textmessage') // Display name
    );

    // Enable/disable factor.
    $settings->add(new admin_setting_configcheckbox(
        'factor_textmessage/enabled',
        get_string('settings_enablefactor', 'factor_textmessage'),
        get_string('settings_enablefactor_help', 'factor_textmessage'),
        0
    ));

    // API Key field.
    $settings->add(new admin_setting_configpasswordunmask(
        'factor_textmessage/apikey',
        get_string('settings_api_key', 'factor_textmessage'),
        get_string('settings_api_key_desc', 'factor_textmessage'),
        ''
    ));

    // Sender ID field.
    $settings->add(new admin_setting_configtext(
        'factor_textmessage/senderid',
        get_string('settings_senderid', 'factor_textmessage'),
        get_string('settings_senderid_desc', 'factor_textmessage'),
        '',
        PARAM_TEXT
    ));

    // Factor weight.
    $settings->add(new admin_setting_configtext(
        'factor_textmessage/weight',
        get_string('settings_weight', 'factor_textmessage'),
        get_string('settings_weight_desc', 'factor_textmessage'),
        100,
        PARAM_INT
    ));

    // Duration (OTP validity).
    $settings->add(new admin_setting_configduration(
        'factor_textmessage/duration',
        get_string('settings_duration', 'factor_textmessage'),
        get_string('settings_duration_desc', 'factor_textmessage'),
        10 * MINSECS,
        MINSECS
    ));

    // **Return the settings object**. Moodle will automatically attach it to tool_mfa.
    return $settings;
}
