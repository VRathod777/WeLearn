<?php
defined('MOODLE_INTERNAL') || die();
 
global $USER;
 
// User mobile number
$mobile = $USER->phone1 ?? '9999999999'; // test number if empty
 
// Fetch API key and Sender ID from plugin settings
$apikey = get_config('factor_textmessage', 'apikey');
$senderid = get_config('factor_textmessage', 'senderid');
 
// Generate OTP (6-digit)
$otp = random_int(100000, 999999);
 
// Ensure country code 91
$mobile = preg_replace('/^0/', '', $mobile);
if (substr($mobile, 0, 2) !== '91') {
    $mobile = '91' . $mobile;
}
 
// Message template
$message = "Your OTP is {#var#}. It is valid for 10 minutes.";
 
// Build API URL
$apiurl = 'https://buzzify.in/V2/http-api.php'
        . '?apikey=' . urlencode($apikey)
        . '&senderid=' . urlencode($senderid)
        . '&number=' . urlencode($mobile)
        . '&message=' . urlencode($message)
        . '&variables_values=' . urlencode($otp)
        . '&format=json';
 
// Debug output
debugging("Buzzify API URL: $apiurl", DEBUG_DEVELOPER);
debugging("Generated OTP: $otp", DEBUG_DEVELOPER);
 
// Optionally, send request
/*
$curl = new \curl();
$response = $curl->get($apiurl);
debugging("Buzzify API Response: " . $response, DEBUG_DEVELOPER);
*/