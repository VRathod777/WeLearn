<?php
// lang/en/factor_textmessage.php

defined('MOODLE_INTERNAL') || die();

$string['pluginname'] = 'Text Message (SMS) MFA Factor';
$string['description'] = 'Send OTP via text message for Multi-Factor Authentication.';

$string['settings_enablefactor'] = 'Enable Text Message MFA';
$string['settings_enablefactor_help'] = 'Enable or disable this MFA factor.';

$string['settings_api_key'] = 'API Key';
$string['settings_api_key_desc'] = 'The API key used to send OTP SMS messages.';

$string['settings_senderid'] = 'Sender ID';
$string['settings_senderid_desc'] = 'The sender ID used to send OTP SMS messages.';

$string['settings_weight'] = 'Factor weight';
$string['settings_weight_desc'] = 'Determines the order of this factor in the MFA list.';

$string['settings_duration'] = 'OTP Duration';
$string['settings_duration_desc'] = 'The duration (in seconds) that the OTP is valid.';
